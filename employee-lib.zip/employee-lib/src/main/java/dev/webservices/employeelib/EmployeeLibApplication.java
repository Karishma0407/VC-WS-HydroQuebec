package dev.webservices.employeelib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLibApplication.class, args);
	}

}
